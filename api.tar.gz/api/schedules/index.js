import startPaymentsSchedules from './payments';
import startPoliciesSchedules from './policies';

export {
  startPaymentsSchedules,
  startPoliciesSchedules,
};
