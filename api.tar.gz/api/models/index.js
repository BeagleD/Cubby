import ShareTempus from './sharetempus';

const sharetempus = ShareTempus.instance;

export default sharetempus;
