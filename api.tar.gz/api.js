require('babel-register');
require('./api/server.js');
